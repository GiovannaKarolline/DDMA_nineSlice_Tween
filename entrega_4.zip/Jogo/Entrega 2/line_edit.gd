extends LineEdit
